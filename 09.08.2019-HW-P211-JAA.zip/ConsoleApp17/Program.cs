﻿using System;
namespace ConsoleApp17
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Please, input Printer ink.");
            string ink = Console.ReadLine();
            Console.WriteLine("Please, input Printer paper.");
            string paper = Console.ReadLine();
            Printer printer = new Printer(decimal.Parse(ink), int.Parse(paper));
            printer.TurnOn();
            Console.WriteLine("Please, input print count.");
            string count = Console.ReadLine();
            printer.ToPrint(int.Parse(count));
            Console.WriteLine("Please, input to charge ink amount.");
            string inkAmount = Console.ReadLine();
            printer.FillInk(decimal.Parse(inkAmount));
            Console.WriteLine("Please, input to charge paper amount.");
            string paperAmount = Console.ReadLine();
            printer.LoadPaper(int.Parse(paperAmount));
            Console.WriteLine("Please, input print count.");
            string newCount = Console.ReadLine();
            printer.ToPrint(int.Parse(newCount));
            printer.TurnOff();
        }
        public class Printer
        {
            public event Action PrinterOn;
            public event Action PrinterOff;
            public event Action PageLoaded;
            public event Action InkFilled;
            public event Action Print;
            public event Action PageFinished;
            public event Action InkFinished;
            private decimal _inkStock;
            public decimal InkStock
            {
                get { return _inkStock; }
                set { _inkStock = value;
                    if (value <= 0 /*&& InkFinished != null*/)
                    {
                        InkFinished += () =>
                        {
                            Console.WriteLine("Catrige Ink finished.");
                        };
                        InkFinished();
                    }
                }
            }
            private int _paperStock;
            public int PaperStock
            {
                get { return _paperStock; }
                set { _paperStock = value;
                    if (value <= 0 /*&& PageFinished != null*/)
                    {
                        PageFinished += () =>
                        {
                            Console.WriteLine("Catrige paper finished.");
                        };
                        PageFinished();
                    }
                }
            }
            
            public Printer(decimal ink, int paper)
            {
                InkFilled += () =>
                {
                    Console.WriteLine("Catrige Ink filled.");
                };
                InkFilled();
                PageLoaded += () =>
                {
                    Console.WriteLine("Catrige Paper loeded.");
                };
                PageLoaded();
            }

            public void TurnOn()
            {
                Console.WriteLine("Start print.");
                PrinterOn += () =>
                {
                    Console.WriteLine("WellCome");
                };
                PrinterOn();
            }
            public void TurnOff()
            {
                Console.WriteLine("Good bye!");
                PrinterOff += () =>
                {
                    Console.WriteLine("Sea you.");
                };
                PrinterOff();
            }
            public void ToPrint(int count)
            {
                for (int i = 0; i < count; i++)
                {
                    Console.WriteLine($"Please, wait. Printing {i+1}-th page.");
                    InkStock -= 0.1M;
                    PaperStock -= 1;
                    Console.Write(InkStock);
                    Console.Write(PaperStock);
                }
                Console.WriteLine("Print ended.");
            }
            public void LoadPaper(int amount)
            {
                Console.WriteLine("It's Ok.");
                PaperStock += amount;
            }
            public void FillInk(decimal amount)
            {
                Console.WriteLine("Ink charged.");
                InkStock += amount;
            }
        }
        
    }
}
